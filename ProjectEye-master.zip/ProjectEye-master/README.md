# ProjectEye
Stereo-vision based project on Python OpenCV
