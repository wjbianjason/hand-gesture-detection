pyStereoWebcam
==============

Using python, openCV, and a pair of cheap webcams for stereo imaging.

Currently, everything is scrambled up on top of some openCV example code. Just trying to get things working.

Using: Python 2.7 snd openCV 2.4

The files common.py, common.pyc, video.py, and video.pyc are from the Python examples folder of openCV.

Developed with: Windows 7 (64 bit) and jEdit
